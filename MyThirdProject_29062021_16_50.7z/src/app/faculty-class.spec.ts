import { FacultyClass } from './faculty-class';

describe('FacultyClass', () => {
  it('should create an instance', () => {
    expect(new FacultyClass()).toBeTruthy();
  });
});
