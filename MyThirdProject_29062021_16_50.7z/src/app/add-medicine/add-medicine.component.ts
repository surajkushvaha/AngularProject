import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-medicine',
  templateUrl: './add-medicine.component.html',
  styleUrls: ['./add-medicine.component.css']
})
export class AddMedicineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
