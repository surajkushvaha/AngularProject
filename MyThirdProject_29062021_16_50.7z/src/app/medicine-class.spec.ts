import { MedicineClass } from './medicine-class';

describe('MedicineClass', () => {
  it('should create an instance', () => {
    expect(new MedicineClass()).toBeTruthy();
  });
});
