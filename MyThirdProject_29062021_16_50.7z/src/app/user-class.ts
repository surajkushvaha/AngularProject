export class UserClass {
    	
records	:string="";
UserID	:number=0;
UserName	:string="";
Password	:string="";
FirstName	:string="";
MiddleName	:string="";
LastName	:string="";
ProfilePicturePath	:string='';
Gender	:string="";
DOB	:string="";
Height	:string="";
Weight	:string="";
HeightestEducationQualification	:string="";
AboutUser	:string="";
Hobbies	:string="";
CurrentJobTitle	:string="";
CurrentSalary	:string="";
TotalExperience	:string="";
MobileNumber	:string="";
EmailAddress	:string="";
ResidentialAddress	:string="";
CityID	:number=0;
CasteID	:number=0;
IsWidow	:string="";
WidowDate	:string="";
IsDivorced	:string="";
DivorceDate	:string="";
IsHandiCapped	:string="";
HandiCappDetail	:string="";
Expectations	:string="";
Created	:string="";
Modified	:string="";
}
