import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-medicine',
  templateUrl: './detail-medicine.component.html',
  styleUrls: ['./detail-medicine.component.css']
})
export class DetailMedicineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
